package Juego;

public interface Consola {

    void consolaimprimir(String mensaje);

    String consolaleer(String descripcion);
}
