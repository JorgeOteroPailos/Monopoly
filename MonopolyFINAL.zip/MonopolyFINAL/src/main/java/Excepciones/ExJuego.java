package Excepciones;

public abstract class ExJuego extends Exception{

    public ExJuego(String mensaje){
        super(mensaje);
    }
}
