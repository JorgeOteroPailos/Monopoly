package Excepciones;

public final class NombreEnUso extends ExJuego {
    public NombreEnUso(String mensaje) {
        super(mensaje);
    }
}
