package Excepciones.Inexistencias;

public final class InexGrup extends Inexistente {

    public InexGrup(String mensaje, String noencontrado) {
        super(mensaje, noencontrado);
    }
}
