package Excepciones.Inexistencias;

public final class InexJug extends Inexistente {

    public InexJug(String mensaje, String noencontrado) {
        super(mensaje, noencontrado);
    }
}
