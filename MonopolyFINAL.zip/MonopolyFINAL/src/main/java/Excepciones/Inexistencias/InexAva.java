package Excepciones.Inexistencias;

public final class InexAva extends Inexistente{
    public InexAva(String mensaje, String noencontrado) {
        super(mensaje, noencontrado);
    }
}
