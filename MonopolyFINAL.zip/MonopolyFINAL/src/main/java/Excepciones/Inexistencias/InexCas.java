package Excepciones.Inexistencias;

public final class InexCas extends Inexistente {

    public InexCas(String mensaje, String noencontrado) {
        super(mensaje, noencontrado);
    }
}
