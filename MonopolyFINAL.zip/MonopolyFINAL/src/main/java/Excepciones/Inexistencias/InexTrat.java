package Excepciones.Inexistencias;

public class InexTrat extends Inexistente{
    public InexTrat(String mensaje, String noencontrado) {
        super(mensaje, noencontrado);
    }
}
