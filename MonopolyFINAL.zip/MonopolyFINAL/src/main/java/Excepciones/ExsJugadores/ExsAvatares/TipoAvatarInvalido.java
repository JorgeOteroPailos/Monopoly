package Excepciones.ExsJugadores.ExsAvatares;

import Jugadores.Jugador;

public final class TipoAvatarInvalido extends ExAvatares{
    public TipoAvatarInvalido(String mensaje, Jugador jugador) {
        super(mensaje, jugador);
    }
}
