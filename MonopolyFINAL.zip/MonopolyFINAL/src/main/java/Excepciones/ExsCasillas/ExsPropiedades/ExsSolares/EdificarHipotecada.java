package Excepciones.ExsCasillas.ExsPropiedades.ExsSolares;

import Juego.Casillas.Propiedades.Solar;

public final class EdificarHipotecada extends ExsSolar {
    public EdificarHipotecada(String mensaje, Solar solar) {
        super(mensaje, solar);
    }
}
