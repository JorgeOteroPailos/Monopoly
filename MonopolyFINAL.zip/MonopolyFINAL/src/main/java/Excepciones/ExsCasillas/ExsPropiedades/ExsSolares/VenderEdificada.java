package Excepciones.ExsCasillas.ExsPropiedades.ExsSolares;

import Juego.Casillas.Propiedades.Solar;

public final class VenderEdificada extends ExsSolar{
    public VenderEdificada(String mensaje, Solar solar) {
        super(mensaje, solar);
    }
}
