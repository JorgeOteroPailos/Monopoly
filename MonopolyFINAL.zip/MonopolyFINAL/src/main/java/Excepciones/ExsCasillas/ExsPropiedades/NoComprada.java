package Excepciones.ExsCasillas.ExsPropiedades;

import Juego.Casillas.Propiedades.Propiedad;

public final class NoComprada extends ExsPropiedad {
    public NoComprada(String mensaje, Propiedad propiedad) {
        super(mensaje, propiedad);
    }
}
