package Excepciones.ExsCasillas.ExsPropiedades.ExsSolares;

import Excepciones.ExsCasillas.ExsPropiedades.ExsPropiedad;
import Juego.Casillas.Propiedades.Solar;

public abstract class ExsSolar extends ExsPropiedad {
    public ExsSolar(String mensaje, Solar solar) {
        super(mensaje, solar);
    }

    //GETTERS

    //SETTERS

}
