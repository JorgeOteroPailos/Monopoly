package Excepciones.ExsCasillas;

import Juego.Casillas.Casilla;

public final class TipoCasillaInvalido extends ExCasillas{
    public TipoCasillaInvalido(String mensaje, Casilla casilla) {
        super(mensaje, casilla);
    }
}
