package Excepciones;


public final class AccionIlegal extends ExJuego {

    public AccionIlegal(String mensaje){
        super(mensaje);
    }
}
