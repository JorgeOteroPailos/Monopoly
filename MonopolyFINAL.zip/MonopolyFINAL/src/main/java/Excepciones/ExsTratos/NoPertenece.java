package Excepciones.ExsTratos;

import Juego.Trato;

public class NoPertenece extends ExTratos{

    public NoPertenece(String mensaje, Trato trato) {
        super(mensaje, trato);
    }
}
