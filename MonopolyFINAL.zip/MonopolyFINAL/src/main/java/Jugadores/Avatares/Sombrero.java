package Jugadores.Avatares;

import Juego.Juego;

public final class Sombrero extends Avatar{
    public Sombrero(char letra) {
        super(letra);
    }

    @Override
    public void moverEnAvanzado(Juego M, String[] splitcom) {

    }
}
