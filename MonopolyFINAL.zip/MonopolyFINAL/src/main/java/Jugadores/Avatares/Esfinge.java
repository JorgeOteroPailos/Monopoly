package Jugadores.Avatares;

import Juego.Juego;

public final class Esfinge extends Avatar{
    public Esfinge(char letra) {
        super( letra);
    }

    @Override
    public void moverEnAvanzado(Juego M, String[] splitcom) {
    }
}
